

/* strtok_r prototype */
char* strtok_r(char *, const char *, char **);